# Future client portal: safe architecture (not built)

No portal, accounts, payments or AI execution exist, and no fake interfaces were added. The public site has no admin UI; the only protected route is the token-gated read-only `GET /api/admin/enquiries`.

## Recommended path
1. Move to Next.js (or similar) with PostgreSQL; keep `public/content.js` as the content module.
2. Authentication via a managed provider (OIDC), MFA for staff, secure httpOnly SameSite cookies, CSRF protection.
3. Tenancy: `organisations`, `memberships(user_id, org_id, role)`. Every query is scoped by the org id derived on the server from the session, never from a client-supplied id. Enforce again in the database with row-level security.
4. Roles: owner, admin, member, viewer (least privilege). Audit log table for every write and sign-in.
5. Modules, in order: project status and documents, support requests, workflow run history, usage and cost summaries, then invoices and subscriptions through a payment provider (Stripe or similar, only with credentials and a legal review).
6. Tests required before launch: cross-tenant access attempts must fail; rate limits; session expiry; audit completeness.
## Internal agency operations
Build as a separate authenticated app area (prospects, proposals, projects, tickets), not on public routes.
