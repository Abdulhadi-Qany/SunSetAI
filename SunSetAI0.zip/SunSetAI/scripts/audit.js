// Accessibility (axe-core in jsdom, contrast rule disabled) and page-weight audit. Usage: npm run audit
const {JSDOM}=require('jsdom'),axe=require('axe-core'),fs=require('fs'),path=require('path'),zlib=require('zlib');
const {createServer}=require('../server'),SITE=require('../public/content.js');
(async()=>{const srv=createServer({dataDir:require('os').tmpdir()+'/sa-audit',env:{SITE_URL:'http://x.test'}});await new Promise(r=>srv.listen(0,r));const base='http://127.0.0.1:'+srv.address().port;let bad=0,rows=[];
for(const r of SITE.R){const gz=zlib.gzipSync(Buffer.from(await(await fetch(base+r[1])).text())).length;
const dom=await JSDOM.fromURL(base+r[1],{runScripts:'dangerously',resources:'usable',pretendToBeVisual:true});await new Promise(x=>setTimeout(x,400));
const w=dom.window;w.eval(axe.source);const res=await w.axe.run(w.document,{rules:{'color-contrast':{enabled:false}}});
bad+=res.violations.length;rows.push([r[1],gz,res.violations.map(v=>v.id+'('+v.nodes.length+')').join(', ')||'none']);w.close()}
console.table(rows.map(x=>({route:x[0],html_gzip_bytes:x[1],axe_violations:x[2]})));
const img=fs.readdirSync(path.join(__dirname,'../public/img')).map(f=>fs.statSync(path.join(__dirname,'../public/img',f)).size);
console.log('content.js gzip bytes:',zlib.gzipSync(fs.readFileSync(path.join(__dirname,'../public/content.js'))).length,'| images:',img.length,'total KB:',Math.round(img.reduce((a,b)=>a+b,0)/1024),'largest KB:',Math.round(Math.max(...img)/1024));
console.log('total axe violations:',bad);srv.close();process.exit(0)})();
