'use strict';
const {GQ,S,I,PK,T,FQ,P,R,PRIV}=require('./public/content.js');
const e=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const path=id=>R.find(r=>r[0]===id)[1];
const L=(id,t)=>`<a href="${path(id)}">${e(t)}</a>`;
const ul=a=>'<ul>'+a.map(x=>'<li>'+x+'</li>').join('')+'</ul>';
const NAV=[['services','Services'],['industries','Industries'],['pricing','Pricing'],['tools','Tools'],['projects','Projects'],['tech','Technology'],['about','About'],['faq','FAQ'],['contact','Contact']];
function crumbs(id){const m=/^([si])(\d+)$/.exec(id);if(!m)return[];return m[1]==='s'?[['Services','services'],[S[m[2]][0],id]]:[['Industries','industries'],[I[m[2]][0],id]]}
function body(id){const m=/^([si])(\d+)$/.exec(id),cr=crumbs(id);
const bc=cr.length?`<nav aria-label="Breadcrumb">${L('home','Home')} / ${cr.map((c,k)=>k<cr.length-1?L(c[1],c[0]):e(c[0])).join(' / ')}</nav>`:'';
const nav='<p>'+NAV.map(n=>L(n[0],n[1])).join(' · ')+'</p>';let h;
if(m&&m[1]==='s'){const i=+m[2],s=S[i];h=`<h1>${e(s[0])}</h1><p>${e(s[3])}</p><h2>Problems solved</h2><p>${e(s[5])}</p><h2>Capabilities</h2>${ul(s[4].split('|').map(e))}<h2>Example workflow</h2><p>${e(s[6])}</p><h2>Deliverables</h2><p>${e(s[9])}</p><h2>KPIs</h2><p>${e(s[7])} ${e(GQ)}</p><h2>Security and oversight</h2><p>${e(s[8])}</p><h2>Related</h2>${ul([(i+1)%14,(i+2)%14].map(k=>L('s'+k,S[k][0])))}<p>${L('pricing','Pricing')} · ${L('contact','Request a proposal')}</p>`}
else if(m){const x=I[+m[2]];h=`<h1>${e(x[0])}</h1><p>${e(x[1])}</p><h2>Automation opportunities</h2>${ul(x[2].split('|').map(e))}<h2>Recommended services</h2>${ul(x[3].map(k=>L('s'+k,S[k][0])))}<h2>Integrations</h2><p>${e(x[4])}</p><h2>Security and regulation</h2><p>${e(x[5])}</p><h2>KPIs</h2><p>${e(x[6])}</p><p>${L('contact','Book an industry consultation')}</p>`}
else{const t={home:()=>`<h1>AI and automation that removes repetitive work</h1><p>SunSet AI Agency designs assistants, workflows, integrations and custom software for businesses, with people in control and honest scoping.</p><h2>Services</h2>${ul(S.map((s,i)=>L('s'+i,s[0])))}<h2>Industries</h2>${ul(I.map((x,i)=>L('i'+i,x[0])))}`,
services:()=>`<h1>Services</h1>${ul(S.map((s,i)=>L('s'+i,s[0])+': '+e(s[3].split('.')[0])+'.'))}`,
industries:()=>`<h1>Industry solutions</h1>${ul(I.map((x,i)=>L('i'+i,x[0])+': '+e(x[1])))}`,
pricing:()=>`<h1>Packages and pricing</h1><p>Draft GBP ranges, subject to approval; not binding quotations.</p>${ul(PK.map(p=>`<b>${e(p[0])}</b>: ${e(p[1])}. Ideal for ${e(p[2])}. Includes ${e(p[3])}. Scope: ${e(p[4])}.`))}`,
tools:()=>`<h1>Interactive tools</h1><p>Automation ROI calculator, rule-based opportunity assessment and a project qualification wizard. JavaScript is required.</p>`,
projects:()=>`<h1>Projects and portfolio</h1><p>Projects supplied by the founder. Screens use sample data; figures are illustrative.</p>${ul(P.map(p=>`<b>${e(p[0])}</b> (${e(p[3])}): ${e(p[2])}`))}`,
tech:()=>`<h1>Technology and integrations</h1><p>Potential technologies only; no partnerships are claimed.</p>${ul(T.map(x=>`<b>${e(x[0])}</b>: ${e(x[1])}. ${e(x[2])}.`))}`,
about:()=>`<h1>About SunSet AI Agency</h1><p>Mission: help businesses remove repetitive work with systems that are measured, secure and understandable.</p><h2>Founder</h2><p>Abdulhadi Qany, Founder. <a href="mailto:a.qany19@gmail.com">a.qany19@gmail.com</a></p>`,
faq:()=>`<h1>Frequently asked questions</h1>${FQ.map(f=>`<h2>${e(f[0])}</h2><p>${e(f[1])}</p>`).join('')}`,
contact:()=>`<h1>Request a consultation</h1><p>Use the form (JavaScript required) or email <a href="mailto:a.qany19@gmail.com">a.qany19@gmail.com</a>.</p>`,
privacy:()=>`<h1>Privacy notice</h1>${PRIV.map(p=>`<p>${e(p)}</p>`).join('')}`,
notfound:()=>`<h1>Page not found</h1><p>That page does not exist. ${L('home','Go to the homepage')}</p>`};h=t[id]()}
return bc+nav+h}
function jsonld(id,base){const url=base+path(id),org={'@type':'Organization',name:'SunSet AI Agency',url:base,email:'a.qany19@gmail.com',founder:{'@type':'Person',name:'Abdulhadi Qany'}},out=[];
if(id==='home')out.push({'@context':'https://schema.org',...org});
const m=/^([si])(\d+)$/.exec(id);
if(m&&m[1]==='s'){const s=S[+m[2]];out.push({'@context':'https://schema.org','@type':'Service',name:s[0],description:s[3].split('.')[0]+'.',url,provider:{'@type':'Organization',name:'SunSet AI Agency',url:base}})}
const cr=crumbs(id);if(cr.length)out.push({'@context':'https://schema.org','@type':'BreadcrumbList',itemListElement:[['Home','home'],...cr].map((c,k)=>({'@type':'ListItem',position:k+1,name:c[0],item:base+path(c[1])}))});
return out}
module.exports={body,jsonld,e};
