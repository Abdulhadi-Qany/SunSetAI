# SunSet AI Agency

Dependency-free Node (>=18) app: server-rendered routes (33 URLs), a shared content module, and a validated enquiry API.

    npm start       # http://localhost:3000
    npm test        # 13 tests (node:test, no dependencies)
    npm install && npm run audit   # axe-core accessibility + page-weight audit (dev dependencies)

## Structure
- `public/content.js`: single source of truth (services, industries, packages, FAQs, projects, technologies, routes, ROI formula). Used by browser and server.
- `public/index.html`: front end. `ssr.js`: pre-rendered body and JSON-LD per route. `server.js`: routes, API, security headers.
- `docs/HANDOVER.md`, `docs/PORTAL-ARCHITECTURE.md`.

## Environment variables (see `.env.example`)
| Variable | Purpose |
|---|---|
| PORT, DATA_DIR | Port; folder for `enquiries.jsonl` (mount a persistent volume) |
| SITE_URL | Public origin used in canonical URLs, sitemap, robots, llms.txt (set to your domain) |
| RATE_LIMIT | Enquiries per IP per hour (default 5); TRUST_PROXY=1 only behind a trusted proxy |
| RETENTION_DAYS | Purge older enquiries at start-up (unset = keep) |
| RESEND_API_KEY, NOTIFY_EMAIL_TO, NOTIFY_EMAIL_FROM | Optional email notification via Resend |
| NOTIFY_WEBHOOK_URL, NOTIFY_WEBHOOK_SECRET | Optional CRM or n8n webhook (receives the full enquiry) |
| ADMIN_TOKEN | Enables `GET /api/admin/enquiries` (Bearer token); endpoint returns 404 when unset |

## Deploy
`docker build -t sunset-ai . && docker run -p 3000:3000 -e SITE_URL=https://your-domain -v sunset-data:/app/data sunset-ai`. Put it behind HTTPS (reverse proxy or host). Back up the data volume.
