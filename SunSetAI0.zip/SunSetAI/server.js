'use strict';
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto'),zlib=require('zlib');
const {R}=require('./public/content.js'),{body,jsonld,e}=require('./ssr');
const MIME={'.html':'text/html; charset=utf-8','.txt':'text/plain; charset=utf-8','.xml':'application/xml','.js':'text/javascript','.css':'text/css','.json':'application/json','.jpg':'image/jpeg','.png':'image/png','.svg':'image/svg+xml'};
const HDR={'X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin','X-Frame-Options':'DENY','Content-Security-Policy':"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"};
const TXT=/^text\/|xml|json/;
function validate(b){const e=[];if(!b||typeof b!=='object'||Array.isArray(b))return['Invalid body.'];
if(b.website)return['Rejected.'];const f=b.fields;if(!f||typeof f!=='object'||Array.isArray(f))return['Missing fields.'];
const k=Object.keys(f);if(!k.length||k.length>20)return['Invalid number of fields.'];
for(const x of k){if(typeof f[x]!=='string'||f[x].length>2000||x.length>120)return['Field too long or not text.']}
const em=k.find(x=>/email/i.test(x));if(!em||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f[em].trim())||f[em].length>254)e.push('A valid email address is required.');
const cs=k.find(x=>/consent|privacy/i.test(x));if(!cs||f[cs]!=='Yes')e.push('Privacy acknowledgement is required.');return e}
function createServer(o={}){const env=o.env||process.env,dir=o.dataDir||env.DATA_DIR||path.join(__dirname,'data'),pub=path.join(__dirname,'public'),max=o.rateLimit||+env.RATE_LIMIT||5,win=o.windowMs||36e5,hits=new Map(),trust=env.TRUST_PROXY==='1',F=o.fetch||globalThis.fetch,file=path.join(dir,'enquiries.jsonl');
const tpl=fs.readFileSync(path.join(pub,'index.html'),'utf8');fs.mkdirSync(dir,{recursive:true});
if(+env.RETENTION_DAYS>0&&fs.existsSync(file)){const cut=Date.now()-env.RETENTION_DAYS*864e5;fs.writeFileSync(file,fs.readFileSync(file,'utf8').split('\n').filter(l=>{try{return l&&Date.parse(JSON.parse(l).at)>=cut}catch(x){return false}}).map(l=>l+'\n').join(''))}
const out=(req,res,c,b,t='application/json',x={})=>{const h={...HDR,'Content-Type':t,...x};let buf=Buffer.isBuffer(b)?b:Buffer.from(typeof b==='string'?b:JSON.stringify(b));
if(TXT.test(t)&&buf.length>1024&&/gzip/.test(req.headers['accept-encoding']||'')){buf=zlib.gzipSync(buf);h['Content-Encoding']='gzip';h.Vary='Accept-Encoding'}
h['Content-Length']=buf.length;res.writeHead(c,h);res.end(req.method==='HEAD'?undefined:buf)};
const base=req=>env.SITE_URL||(/^[a-z0-9.:-]+$/i.test(req.headers.host||'')?'http://'+req.headers.host:'http://localhost');
const page=(id,req,code)=>{const b=base(req),r=R.find(x=>x[0]===id),nf=!r,t=nf?'Page not found | SunSet AI Agency':r[2],d=nf?'Page not found.':r[3];
const seo=[`<link rel="canonical" href="${e(b+(nf?'/':r[1]))}">`,`<meta property="og:site_name" content="SunSet AI Agency"><meta property="og:type" content="website"><meta property="og:title" content="${e(t)}"><meta property="og:description" content="${e(d)}">`,nf?'<meta name="robots" content="noindex">':`<meta property="og:url" content="${e(b+r[1])}">`,'<meta name="twitter:card" content="summary">',...(nf?[]:jsonld(id,b)).map(j=>'<script type="application/ld+json">'+JSON.stringify(j).replace(/</g,'\\u003c')+'</script>')].join('\n');
return tpl.replace(/<title>.*?<\/title>/,'<title>'+e(t)+'</title>').replace(/<meta name="description" content="[^"]*">/,'<meta name="description" content="'+e(d)+'">').replace('<!--SEO-->',seo).replace('<!--BODY-->',body(nf?'notfound':id))};
const srv=http.createServer((req,res)=>{const url=new URL(req.url,'http://x'),pn=url.pathname;
if(pn==='/healthz')return out(req,res,200,{ok:true});
if(pn==='/api/admin/enquiries'){const t=env.ADMIN_TOKEN;if(!t)return out(req,res,404,{error:'Not found.'});const a=Buffer.from(req.headers.authorization||''),b=Buffer.from('Bearer '+t);
if(a.length!==b.length||!crypto.timingSafeEqual(a,b))return out(req,res,401,{error:'Unauthorised.'},'application/json',{'Cache-Control':'no-store'});
const l=fs.existsSync(file)?fs.readFileSync(file,'utf8').split('\n').filter(Boolean).slice(-200).map(x=>JSON.parse(x)):[];return out(req,res,200,{enquiries:l},'application/json',{'Cache-Control':'no-store'})}
if(pn==='/api/enquiry'){if(req.method!=='POST')return out(req,res,405,{error:'Method not allowed.'});
if(!/^application\/json/.test(req.headers['content-type']||''))return out(req,res,415,{error:'JSON required.'});
const ip=(trust&&(req.headers['x-forwarded-for']||'').split(',')[0].trim())||req.socket.remoteAddress,now=Date.now(),h=(hits.get(ip)||[]).filter(t=>now-t<win);
if(h.length>=max)return out(req,res,429,{error:'Too many enquiries. Please try later.'});
let b='',big=0;req.on('data',c=>{if(big)return;b+=c;if(b.length>20000){big=1;out(req,res,413,{error:'Request too large.'})}});
req.on('end',()=>{if(big)return;let j;try{j=JSON.parse(b)}catch(x){return out(req,res,400,{error:'Invalid JSON.'})}
const errs=validate(j);if(errs.length)return out(req,res,400,{errors:errs});
h.push(now);hits.set(ip,h);const entry={id:crypto.randomUUID().slice(0,8),at:new Date().toISOString(),fields:j.fields};
try{fs.appendFileSync(file,JSON.stringify(entry)+'\n')}catch(x){console.error('persist failed');return out(req,res,500,{error:'Could not save your enquiry. Please email us instead.'})}
srv.lastNotify=notify(entry);out(req,res,201,{id:entry.id})});return}
async function notify(en){const text=Object.entries(en.fields).map(([k,v])=>k+': '+v).join('\n'),jobs=[];
if(env.RESEND_API_KEY&&env.NOTIFY_EMAIL_TO&&env.NOTIFY_EMAIL_FROM)jobs.push(F('https://api.resend.com/emails',{method:'POST',headers:{Authorization:'Bearer '+env.RESEND_API_KEY,'Content-Type':'application/json'},body:JSON.stringify({from:env.NOTIFY_EMAIL_FROM,to:[env.NOTIFY_EMAIL_TO],subject:'New SunSet AI enquiry '+en.id,text})}));
if(env.NOTIFY_WEBHOOK_URL)jobs.push(F(env.NOTIFY_WEBHOOK_URL,{method:'POST',headers:{'Content-Type':'application/json',...(env.NOTIFY_WEBHOOK_SECRET?{'X-Webhook-Secret':env.NOTIFY_WEBHOOK_SECRET}:{})},body:JSON.stringify(en)}));
(await Promise.allSettled(jobs)).forEach(x=>{if(x.status==='rejected'||(x.value&&x.value.ok===false))console.error('notify failed')});return jobs.length}
if(req.method!=='GET'&&req.method!=='HEAD')return out(req,res,405,{error:'Method not allowed.'});
const b=base(req);
if(pn==='/robots.txt')return out(req,res,200,`User-agent: *\nAllow: /\nDisallow: /api/\nSitemap: ${b}/sitemap.xml\n`,MIME['.txt']);
if(pn==='/sitemap.xml')return out(req,res,200,`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${R.map(r=>`<url><loc>${e(b+r[1])}</loc></url>`).join('')}</urlset>\n`,MIME['.xml']);
if(pn==='/llms.txt')return out(req,res,200,`# SunSet AI Agency\n> AI assistants, automation, integrations and custom software for businesses. Founder: Abdulhadi Qany.\n\n## Pages\n${R.map(r=>`- [${r[2]}](${b+r[1]}): ${r[3]}`).join('\n')}\n\nPrices are draft proposals, not binding quotations.\n`,MIME['.txt']);
if(pn.length>1&&pn.endsWith('/'))return(res.writeHead(301,{...HDR,Location:pn.replace(/\/+$/,'')+url.search}),res.end());
const rt=R.find(r=>r[1]===pn);if(rt)return out(req,res,200,page(rt[0],req),MIME['.html'],{'Cache-Control':'no-cache'});
let p;try{p=decodeURIComponent(pn)}catch(x){return out(req,res,400,'Bad request','text/plain')}
const f=path.normalize(path.join(pub,p));
if(!f.startsWith(pub+path.sep))return out(req,res,403,'Forbidden','text/plain');
if(p==='/index.html'||!fs.existsSync(f)||fs.statSync(f).isDirectory())return out(req,res,404,page('notfound',req),MIME['.html']);
out(req,res,200,fs.readFileSync(f),MIME[path.extname(f)]||'application/octet-stream',{'Cache-Control':f.includes(path.sep+'img'+path.sep)?'public, max-age=86400':'no-cache'})});
return srv}
if(require.main===module){const port=+process.env.PORT||3000;createServer().listen(port,()=>console.log('SunSet AI on :'+port))}
module.exports={createServer,validate};
